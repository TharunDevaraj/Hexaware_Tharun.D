package exceptions;

public class IncidentNumberNotFoundException extends Exception{
	
	public IncidentNumberNotFoundException(String msg)
	{
		super(msg);
	}
}
