package exceptions;

public class SuspectIdNotFoundException extends Exception{

	public SuspectIdNotFoundException(String msg)
	{
		super(msg);
	}
}
