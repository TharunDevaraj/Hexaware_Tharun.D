package exceptions;

public class OfficerIdNotFoundException extends Exception{

	public OfficerIdNotFoundException(String msg)
	{
		super(msg);
	}
}
