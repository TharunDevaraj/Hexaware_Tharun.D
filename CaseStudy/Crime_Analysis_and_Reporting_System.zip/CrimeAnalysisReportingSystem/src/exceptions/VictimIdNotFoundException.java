package exceptions;

public class VictimIdNotFoundException extends Exception{
	
	public VictimIdNotFoundException(String msg)
	{
		super(msg);
	}

}
