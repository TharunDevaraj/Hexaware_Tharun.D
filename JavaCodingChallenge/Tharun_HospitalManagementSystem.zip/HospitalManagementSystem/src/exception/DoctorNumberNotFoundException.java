package exception;

public class DoctorNumberNotFoundException extends Exception{

	public DoctorNumberNotFoundException(String msg)
	{
		super(msg);
	}
}
