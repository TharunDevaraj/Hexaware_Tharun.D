package exception;

public class AppointmentNotFoundException extends Exception{
	
	public AppointmentNotFoundException(String msg)
	{
		super(msg);
	}

}
