package exception;

public class PatientNumberNotFoundException extends Exception{

	public PatientNumberNotFoundException(String msg)
	{
		super(msg);
	}
}
